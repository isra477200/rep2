# Kit comercial B2B de RedVitalia

Este kit sirve para que RedVitalia capte y cierre **empresas que contratarán la gestión de su publicidad y captación**. No contiene guiones para vender los servicios finales de esas empresas a consumidores.

## Qué usar en cada momento

1. **Primera llamada:** `03-MANUAL-PROSPECCION-Y-LLAMADA-FRIA`.
2. **Preparación de la reunión:** `02-PLAYBOOK-CLOSER-POR-VERTICALES`.
3. **Reunión con el prospecto:** `01-PRESENTACION-COMERCIAL-REDVITALIA`.
4. **Diagnóstico, objeciones y decisión:** `04-MANUAL-CLOSER-REDVITALIA`.

Cada material se entrega en PDF y en formato editable (PPTX o DOCX). `INDEX.html` funciona como portada visual del paquete e `INVENTARIO.csv` permite comprobar tamaño e integridad SHA-256 de cada archivo principal.

## Límites comerciales

- No prometer ventas, rentabilidad, sentencias, tratamientos ni resultados no controlables.
- No inventar clientes, métricas, testimonios o casos de éxito.
- Usar únicamente la tarifa y las condiciones de la fuente canónica vigente.
- No activar captación para una empresa sin capacidad, margen, trazabilidad o aprobación humana.
- Antes de operar listas o secuencias, RedVitalia debe validar procedencia de datos, canal, identificación, oposición y requisitos legales aplicables.

## Estado

Material preparado para uso y adaptación por el equipo comercial. La publicación de campañas y el uso de datos reales de prospectos siguen sujetos a validación humana.
