# Paquete herencias-b2c

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Generar consulta efectiva y asunto de herencia aceptado para la empresa contratada.

## Público

Heredero, legitimario o persona con interés acreditable en la sucesión.

## Oferta

Funnel separado por conflicto, inmueble, deuda e internacional, con agenda y seguimiento de ciclos largos.

## Landing propuesta

/landings/herencias

## Conversión principal

`asunto_aceptado_herencias`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No anticipar adjudicación, plazos ni resultado; separar información inicial del asesoramiento jurídico.
