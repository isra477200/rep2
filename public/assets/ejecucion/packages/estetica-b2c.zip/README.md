# Paquete estetica-b2c

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Generar valoración clínica asistida y tratamiento vendido para la empresa contratada.

## Público

Adulto interesado en un tratamiento concreto y una valoración profesional.

## Oferta

Sistema monoproducto con compliance, confirmación humana y retorno de venta.

## Landing propuesta

/landings/valoracion-estetica

## Conversión principal

`tratamiento_vendido`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No diagnosticar, avergonzar ni garantizar resultados; revisar claims y uso de antes/después.
