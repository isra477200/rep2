# Paquete coches-b2b

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Conseguir que empresas de compra de vehículos problemáticos soliciten una reunión de diagnóstico con RedVitalia.

## Público

Dirección de compras o gerente con liquidez y logística.

## Oferta

Auditoría del recorrido actual + piloto de silos por reserva, embargo, financiado, avería y siniestro; valoración y eventos offline por margen.

## Landing propuesta

/landings/coches-b2b

## Conversión principal

`reunion_b2b_coches`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

Diferenciar tasación, oferta y compra. No garantizar valoración ni compra inmediata.
