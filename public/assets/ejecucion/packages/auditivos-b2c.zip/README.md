# Paquete auditivos-b2c

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Generar valoración asistida y solución propuesta con seguimiento para la empresa contratada.

## Público

Adulto o familiar que solicita una valoración profesional.

## Oferta

Funnel accesible, local y prudente con recordatorios y privacidad.

## Landing propuesta

/landings/valoracion-auditiva

## Conversión principal

`solucion_propuesta_auditiva`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No diagnosticar ni prometer mejora; cuidar consentimiento y representación digna.
