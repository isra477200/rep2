# Paquete climatizacion-b2c

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Generar visita técnica o trabajo válido con valor registrado para la empresa contratada.

## Público

Propietario o decisor con una instalación, sustitución o avería concreta.

## Oferta

Campañas por servicio, zona y franja, sincronizadas con capacidad diaria.

## Landing propuesta

/landings/aerotermia

## Conversión principal

`trabajo_valido_climatizacion`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No prometer ahorro ni plazo sin cálculo y capacidad; diferenciar reparación e instalación.
