# Paquete divorcios-b2c

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Generar consulta efectiva y asunto de familia aceptado para la empresa contratada.

## Público

Cónyuge que busca una revisión profesional de su situación.

## Oferta

Captación separada para mutuo acuerdo, contencioso y modificación de medidas, con mensajes y economía propios.

## Landing propuesta

/landings/divorcios

## Conversión principal

`asunto_aceptado_divorcios`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No prometer custodia, pensión, plazo ni sentencia; no usar a menores ni miedo como recurso creativo.
