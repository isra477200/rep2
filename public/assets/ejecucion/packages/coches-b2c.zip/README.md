# Paquete coches-b2c

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Generar vehículo valorable con oferta emitida y margen registrado para la empresa contratada.

## Público

Propietario o representante acreditado que quiere vender.

## Oferta

Silos por reserva, embargo, financiado, avería y siniestro; valoración y eventos offline por margen.

## Landing propuesta

/landings/vender-coche-con-cargas

## Conversión principal

`oferta_emitida_vehiculo`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

Diferenciar tasación, oferta y compra. No garantizar valoración ni compra inmediata.
