# Paquete inmobiliario-b2c

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Generar visita de captación efectiva y encargo firmado para la empresa contratada.

## Público

Propietario con intención, autoridad y horizonte de venta.

## Oferta

Captación hiperlocal con valoración documentada, nurturing y retorno de encargo.

## Landing propuesta

/landings/vender-vivienda

## Conversión principal

`encargo_firmado`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No discriminar, fingir compradores ni garantizar precio o plazo de venta.
