# Paquete reformas-b2b

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Conseguir que empresas de reformas de alto valor soliciten una reunión de diagnóstico con RedVitalia.

## Público

Gerencia o dirección comercial de la reformista.

## Oferta

Auditoría del recorrido actual + piloto de funnel de proyecto con umbral económico, portfolio real y seguimiento de 90 días.

## Landing propuesta

/landings/reformas-b2b

## Conversión principal

`reunion_b2b_reformas`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No usar trabajos ajenos ni prometer fecha o precio sin visita.
