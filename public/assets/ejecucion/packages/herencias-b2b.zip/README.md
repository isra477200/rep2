# Paquete herencias-b2b

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Conseguir que empresas de sistema jurídico soliciten una reunión de diagnóstico con RedVitalia.

## Público

Socio director o abogado responsable de sucesiones.

## Oferta

Auditoría del recorrido actual + piloto de funnel separado por conflicto, inmueble, deuda e internacional, con agenda y seguimiento de ciclos largos.

## Landing propuesta

/landings/herencias-b2b

## Conversión principal

`reunion_b2b_herencias`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No anticipar adjudicación, plazos ni resultado; separar información inicial del asesoramiento jurídico.
