# Paquete auditivos-b2b

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Conseguir que empresas de centros auditivos y ortopedias soliciten una reunión de diagnóstico con RedVitalia.

## Público

Gerencia o dirección del centro.

## Oferta

Auditoría del recorrido actual + piloto de funnel accesible, local y prudente con recordatorios y privacidad.

## Landing propuesta

/landings/auditivos-b2b

## Conversión principal

`reunion_b2b_auditivos`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No diagnosticar ni prometer mejora; cuidar consentimiento y representación digna.
