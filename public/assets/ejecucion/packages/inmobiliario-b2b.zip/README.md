# Paquete inmobiliario-b2b

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Conseguir que empresas de captación de propietarios soliciten una reunión de diagnóstico con RedVitalia.

## Público

Gerencia o director de oficina inmobiliaria.

## Oferta

Auditoría del recorrido actual + piloto de captación hiperlocal con valoración documentada, nurturing y retorno de encargo.

## Landing propuesta

/landings/inmobiliario-b2b

## Conversión principal

`reunion_b2b_inmobiliario`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No discriminar, fingir compradores ni garantizar precio o plazo de venta.
