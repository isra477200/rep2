# Paquete toldos-b2c

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Generar visita técnica efectiva para proyecto dentro de ticket y zona para la empresa contratada.

## Público

Propietario o decisor con espacio, presupuesto y plazo de instalación.

## Oferta

Sistema local por producto de alto valor, con fotos, medidas y visita cualificada.

## Landing propuesta

/landings/pergolas

## Conversión principal

`visita_efectiva_pergolas`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No inventar precio cerrado ni plazo; usar solo obras autorizadas como prueba.
