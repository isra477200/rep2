# Paquete estetica-b2b

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Conseguir que empresas de clínicas estéticas y capilares soliciten una reunión de diagnóstico con RedVitalia.

## Público

Gerencia o dirección de clínica con coordinador comercial.

## Oferta

Auditoría del recorrido actual + piloto de sistema monoproducto con compliance, confirmación humana y retorno de venta.

## Landing propuesta

/landings/estetica-b2b

## Conversión principal

`reunion_b2b_estetica`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No diagnosticar, avergonzar ni garantizar resultados; revisar claims y uso de antes/después.
