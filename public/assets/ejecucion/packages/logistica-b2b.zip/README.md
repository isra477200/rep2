# Paquete logistica-b2b

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Conseguir que empresas de contenedores, mudanzas y guardamuebles soliciten una reunión de diagnóstico con RedVitalia.

## Público

Gerencia o responsable de operaciones.

## Oferta

Auditoría del recorrido actual + piloto de captación por intención, volumen y ruta, conectada con capacidad y presupuesto rápido.

## Landing propuesta

/landings/logistica-b2b

## Conversión principal

`reunion_b2b_logistica`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No prometer fecha ni precio sin inventario, accesos y capacidad real.
