# Paquete reformas-b2c

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Generar visita cualificada, presupuesto emitido y obra ganada con margen para la empresa contratada.

## Público

Propietario o decisor con alcance, presupuesto y plazo compatibles.

## Oferta

Funnel de proyecto con umbral económico, portfolio real y seguimiento de 90 días.

## Landing propuesta

/landings/reforma-integral

## Conversión principal

`obra_ganada`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No usar trabajos ajenos ni prometer fecha o precio sin visita.
