# Paquete divorcios-b2b

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Conseguir que empresas de sistema jurídico soliciten una reunión de diagnóstico con RedVitalia.

## Público

Socio director o responsable del área de familia.

## Oferta

Auditoría del recorrido actual + piloto de captación separada para mutuo acuerdo, contencioso y modificación de medidas, con mensajes y economía propios.

## Landing propuesta

/landings/divorcios-b2b

## Conversión principal

`reunion_b2b_divorcios`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

No prometer custodia, pensión, plazo ni sentencia; no usar a menores ni miedo como recurso creativo.
