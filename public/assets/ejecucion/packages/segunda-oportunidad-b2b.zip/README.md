# Paquete segunda-oportunidad-b2b

## Qué contiene

- Briefing completo de campaña en `campana.json`.
- Propuesta de landing en `landing.json`.
- Inventario de archivos en `inventario-creativo.csv`.
- 6 conceptos y 42 imágenes JPG reales en `creatividades/`.

## Objetivo

Conseguir que empresas de sistema jurídico soliciten una reunión de diagnóstico con RedVitalia.

## Público

Socio director o responsable de desarrollo de negocio del despacho.

## Oferta

Auditoría del recorrido actual + piloto de sistema de captación y seguimiento por especialidad, con cualificación previa y devolución de resultado al crm.

## Landing propuesta

/landings/segunda-oportunidad-b2b

## Conversión principal

`reunion_b2b_segunda_oportunidad`

## Estado honesto

El contenido, la estructura y las adaptaciones visuales están preparados para revisión. No se deben publicar hasta incorporar la marca real del cliente, pruebas autorizadas, datos operativos, privacidad y aprobación humana. Los archivos de vídeo no se presentan como terminados: el paquete conserva únicamente guion, storyboard y fotogramas cuando corresponde.

## Restricción sectorial

Información general y precalificación; nunca afirmar que cumple requisitos ni garantizar resultado judicial.
